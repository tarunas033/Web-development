import React from "react";

export const MovieCard = () => {
  return <div className={"movie-card"}></div>;
};
