export const MovieDetail = () => {
  return (
    <div>
      <h3 className="movie-id">
        {/* Show Movie Id here, Do not add any extra text */}
      </h3>
      {/* Show Movie details here */}
    </div>
  );
};
