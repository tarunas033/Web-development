export type Student={
    id:number,
    name:string,
    image:string,
    vote:number,
    batch:string,
    code:string
    
   

}
export type Entry={
    name:string,
    image:string,
    vote:number,
    batch:string,
    code:string

 
}