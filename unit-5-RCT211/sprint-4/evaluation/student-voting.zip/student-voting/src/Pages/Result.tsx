import React from 'react'

const Result = () => {
  return (
    <div>
      
    </div>
  )
}

export default Result
