npx create-react-app student-voting --template typescript

create folder structure